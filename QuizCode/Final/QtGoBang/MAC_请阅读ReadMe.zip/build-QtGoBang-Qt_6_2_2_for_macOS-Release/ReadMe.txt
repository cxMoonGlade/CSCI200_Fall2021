Dear user,

Welcome to my gobang macOS application,
please copy the "QtGoBang.app" file to your "Applications" file in Finder

Or you can use terminal command to do this.

Open your terminial then using cd command to the direction you downloaded this file folder.

then do
$cp -R ~/QtGoBang.app ../../Applications

After everything, you can just open and enjoy this game.
